import { type NextRequest, NextResponse } from "next/server"

// In-memory storage reference (same as in route.ts)
const transactions: Array<{
  id: string
  type: "income" | "expense"
  category: string
  amount: number
  date: string
  description: string
}> = [
  {
    id: "1",
    type: "income",
    category: "Salary",
    amount: 5000,
    date: "2024-10-01",
    description: "Monthly salary",
  },
  {
    id: "2",
    type: "expense",
    category: "Food",
    amount: 450,
    date: "2024-10-05",
    description: "Groceries and dining",
  },
  {
    id: "3",
    type: "expense",
    category: "Transport",
    amount: 200,
    date: "2024-10-10",
    description: "Gas and maintenance",
  },
  {
    id: "4",
    type: "income",
    category: "Freelance",
    amount: 1200,
    date: "2024-10-15",
    description: "Project payment",
  },
  {
    id: "5",
    type: "expense",
    category: "Entertainment",
    amount: 150,
    date: "2024-10-18",
    description: "Movies and games",
  },
]

// DELETE /api/transactions/[id] - Delete a transaction
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const transactionIndex = transactions.findIndex((t) => t.id === id)

    if (transactionIndex === -1) {
      return NextResponse.json({ success: false, error: "Transaction not found" }, { status: 404 })
    }

    const deletedTransaction = transactions.splice(transactionIndex, 1)[0]

    return NextResponse.json({
      success: true,
      data: deletedTransaction,
      message: "Transaction deleted successfully",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to delete transaction" }, { status: 500 })
  }
}

// GET /api/transactions/[id] - Get a specific transaction
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const transaction = transactions.find((t) => t.id === id)

    if (!transaction) {
      return NextResponse.json({ success: false, error: "Transaction not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: transaction,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch transaction" }, { status: 500 })
  }
}
