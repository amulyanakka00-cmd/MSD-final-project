import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for demo purposes
// In production, this would be a database
const transactions: Array<{
  id: string
  type: "income" | "expense"
  category: string
  amount: number
  date: string
  description: string
}> = [
  {
    id: "1",
    type: "income",
    category: "Salary",
    amount: 5000,
    date: "2024-10-01",
    description: "Monthly salary",
  },
  {
    id: "2",
    type: "expense",
    category: "Food",
    amount: 450,
    date: "2024-10-05",
    description: "Groceries and dining",
  },
  {
    id: "3",
    type: "expense",
    category: "Transport",
    amount: 200,
    date: "2024-10-10",
    description: "Gas and maintenance",
  },
  {
    id: "4",
    type: "income",
    category: "Freelance",
    amount: 1200,
    date: "2024-10-15",
    description: "Project payment",
  },
  {
    id: "5",
    type: "expense",
    category: "Entertainment",
    amount: 150,
    date: "2024-10-18",
    description: "Movies and games",
  },
]

// GET /api/transactions - Retrieve all transactions
export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      data: transactions,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch transactions" }, { status: 500 })
  }
}

// POST /api/transactions - Create a new transaction
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, category, amount, date, description } = body

    // Validation
    if (!type || !category || !amount || !date) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 })
    }

    if (!["income", "expense"].includes(type)) {
      return NextResponse.json({ success: false, error: "Invalid transaction type" }, { status: 400 })
    }

    if (amount <= 0) {
      return NextResponse.json({ success: false, error: "Amount must be greater than 0" }, { status: 400 })
    }

    const newTransaction = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      category,
      amount: Number.parseFloat(amount),
      date,
      description: description || "",
    }

    transactions.unshift(newTransaction)

    return NextResponse.json(
      {
        success: true,
        data: newTransaction,
        message: "Transaction created successfully",
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to create transaction" }, { status: 500 })
  }
}
