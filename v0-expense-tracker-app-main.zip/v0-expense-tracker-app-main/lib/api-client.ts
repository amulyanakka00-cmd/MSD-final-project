// API client utility for making requests to the backend

interface Transaction {
  id: string
  type: "income" | "expense"
  category: string
  amount: number
  date: string
  description: string
}

interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export const apiClient = {
  // Fetch all transactions
  async getTransactions(): Promise<Transaction[]> {
    try {
      const response = await fetch("/api/transactions")
      const result: ApiResponse<Transaction[]> = await response.json()

      if (!result.success) {
        throw new Error(result.error || "Failed to fetch transactions")
      }

      return result.data || []
    } catch (error) {
      console.error("Error fetching transactions:", error)
      throw error
    }
  },

  // Create a new transaction
  async createTransaction(transaction: Omit<Transaction, "id">): Promise<Transaction> {
    try {
      const response = await fetch("/api/transactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(transaction),
      })

      const result: ApiResponse<Transaction> = await response.json()

      if (!result.success) {
        throw new Error(result.error || "Failed to create transaction")
      }

      return result.data!
    } catch (error) {
      console.error("Error creating transaction:", error)
      throw error
    }
  },

  // Delete a transaction
  async deleteTransaction(id: string): Promise<void> {
    try {
      const response = await fetch(`/api/transactions/${id}`, {
        method: "DELETE",
      })

      const result: ApiResponse<Transaction> = await response.json()

      if (!result.success) {
        throw new Error(result.error || "Failed to delete transaction")
      }
    } catch (error) {
      console.error("Error deleting transaction:", error)
      throw error
    }
  },

  // Get a specific transaction
  async getTransaction(id: string): Promise<Transaction> {
    try {
      const response = await fetch(`/api/transactions/${id}`)
      const result: ApiResponse<Transaction> = await response.json()

      if (!result.success) {
        throw new Error(result.error || "Failed to fetch transaction")
      }

      return result.data!
    } catch (error) {
      console.error("Error fetching transaction:", error)
      throw error
    }
  },
}
