"use client"

import { Card } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Wallet } from "lucide-react"

interface BalanceDisplayProps {
  balance: number
  income: number
  expenses: number
}

export function BalanceDisplay({ balance, income, expenses }: BalanceDisplayProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Total Balance Card */}
      <Card className="bg-gradient-to-br from-blue-500 to-purple-600 border-0 shadow-xl overflow-hidden">
        <div className="p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold opacity-90">Total Balance</h3>
            <Wallet className="w-5 h-5 opacity-80" />
          </div>
          <p className="text-4xl font-bold mb-2">${balance.toFixed(2)}</p>
          <p className="text-sm opacity-80">Your current balance</p>
        </div>
      </Card>

      {/* Income Card */}
      <Card className="bg-gradient-to-br from-green-400 to-emerald-500 border-0 shadow-xl overflow-hidden">
        <div className="p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold opacity-90">Total Income</h3>
            <TrendingUp className="w-5 h-5 opacity-80" />
          </div>
          <p className="text-4xl font-bold mb-2">${income.toFixed(2)}</p>
          <p className="text-sm opacity-80">Money earned</p>
        </div>
      </Card>

      {/* Expenses Card */}
      <Card className="bg-gradient-to-br from-red-400 to-orange-500 border-0 shadow-xl overflow-hidden">
        <div className="p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold opacity-90">Total Expenses</h3>
            <TrendingDown className="w-5 h-5 opacity-80" />
          </div>
          <p className="text-4xl font-bold mb-2">${expenses.toFixed(2)}</p>
          <p className="text-sm opacity-80">Money spent</p>
        </div>
      </Card>
    </div>
  )
}
