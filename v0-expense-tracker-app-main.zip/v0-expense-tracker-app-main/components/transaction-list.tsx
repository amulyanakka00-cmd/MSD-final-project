"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2, TrendingUp, TrendingDown } from "lucide-react"

interface Transaction {
  id: string
  type: "income" | "expense"
  category: string
  amount: number
  date: string
  description: string
}

interface TransactionListProps {
  transactions: Transaction[]
  onDelete: (id: string) => void
}

export function TransactionList({ transactions, onDelete }: TransactionListProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const recentTransactions = transactions.slice(0, 10)

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Recent Transactions</CardTitle>
        <CardDescription className="text-slate-400">
          Your latest {recentTransactions.length} transactions
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {recentTransactions.length === 0 ? (
            <p className="text-slate-400 text-center py-8">No transactions yet</p>
          ) : (
            recentTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition-colors"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div
                    className={`p-2 rounded-lg ${
                      transaction.type === "income" ? "bg-emerald-500/20" : "bg-red-500/20"
                    }`}
                  >
                    {transaction.type === "income" ? (
                      <TrendingUp
                        className={`w-5 h-5 ${transaction.type === "income" ? "text-emerald-400" : "text-red-400"}`}
                      />
                    ) : (
                      <TrendingDown className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">{transaction.category}</p>
                    <p className="text-slate-400 text-sm">{transaction.description || "No description"}</p>
                    <p className="text-slate-500 text-xs mt-1">{formatDate(transaction.date)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <p
                    className={`font-bold text-lg ${transaction.type === "income" ? "text-emerald-400" : "text-red-400"}`}
                  >
                    {transaction.type === "income" ? "+" : "-"}
                    {formatCurrency(transaction.amount)}
                  </p>
                  <Button
                    onClick={() => onDelete(transaction.id)}
                    variant="ghost"
                    size="sm"
                    className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
