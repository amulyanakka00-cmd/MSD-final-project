"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface MonthlyChartProps {
  data: Record<string, { income: number; expense: number }>
}

export function MonthlyChart({ data }: MonthlyChartProps) {
  const chartData = Object.entries(data)
    .sort()
    .map(([month, values]) => ({
      month: new Date(month + "-01").toLocaleDateString("en-US", { month: "short", year: "2-digit" }),
      income: values.income,
      expense: values.expense,
    }))

  if (chartData.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-blue-700">Monthly Overview</CardTitle>
          <CardDescription className="text-blue-600">No data yet</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-blue-700">Monthly Overview</CardTitle>
        <CardDescription className="text-blue-600">Income vs Expenses</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
            <XAxis dataKey="month" stroke="#6366f1" />
            <YAxis stroke="#6366f1" />
            <Tooltip
              contentStyle={{ backgroundColor: "#f0f9ff", border: "2px solid #0ea5e9", borderRadius: "8px" }}
              formatter={(value) => `$${value}`}
            />
            <Legend />
            <Bar dataKey="income" fill="#10b981" radius={[8, 8, 0, 0]} />
            <Bar dataKey="expense" fill="#ef4444" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
