"use client"

import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Wallet } from "lucide-react"

interface BalanceDisplayProps {
  balance: number
  income: number
  expenses: number
}

export function BalanceDisplay({ balance, income, expenses }: BalanceDisplayProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="md:col-span-1 bg-gradient-to-br from-purple-500 via-purple-400 to-indigo-500 border-0 shadow-xl hover:shadow-2xl transition-shadow">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-3">
            <p className="text-white/90 text-sm font-semibold tracking-wide">Total Balance</p>
            <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
              <Wallet className="w-6 h-6 text-white" />
            </div>
          </div>
          <h2 className="text-5xl font-bold text-white mb-2">{formatCurrency(balance)}</h2>
          <p className="text-white/80 text-sm">{balance >= 0 ? "You're in great shape" : "Time to earn more"}</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 shadow-lg hover:shadow-xl transition-shadow">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-3">
            <p className="text-green-700 text-sm font-semibold tracking-wide">Total Income</p>
            <div className="bg-green-100 p-3 rounded-xl">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-4xl font-bold text-green-700">{formatCurrency(income)}</h3>
          <p className="text-green-600 text-sm mt-2">All sources combined</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-200 shadow-lg hover:shadow-xl transition-shadow">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-3">
            <p className="text-red-700 text-sm font-semibold tracking-wide">Total Expenses</p>
            <div className="bg-red-100 p-3 rounded-xl">
              <TrendingDown className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <h3 className="text-4xl font-bold text-red-700">{formatCurrency(expenses)}</h3>
          <p className="text-red-600 text-sm mt-2">All categories combined</p>
        </CardContent>
      </Card>
    </div>
  )
}
