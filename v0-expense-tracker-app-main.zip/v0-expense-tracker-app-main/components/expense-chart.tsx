"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"

interface ExpenseChartProps {
  data: Record<string, number>
}

export function ExpenseChart({ data }: ExpenseChartProps) {
  const chartData = Object.entries(data).map(([name, value]) => ({
    name,
    value,
  }))

  /* Updated to bright, vibrant red and orange colors for expense chart */
  const COLORS = ["#ef4444", "#f87171", "#fb7185", "#fca5a5", "#fecaca"]

  if (chartData.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-red-700">Expenses by Category</CardTitle>
          <CardDescription className="text-red-600">No expense data yet</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-red-700">Expenses by Category</CardTitle>
        <CardDescription className="text-red-600">Distribution of spending</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, value }) => `${name}: $${value}`}
              outerRadius={90}
              fill="#8884d8"
              dataKey="value"
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value) => `$${value}`}
              contentStyle={{ backgroundColor: "#fef2f2", border: "2px solid #ef4444", borderRadius: "8px" }}
            />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
