"use client"

import { useState, useMemo, useEffect } from "react"
import { BalanceDisplay } from "./balance-display"
import { TransactionForm } from "./transaction-form"
import { IncomeChart } from "./income-chart"
import { ExpenseChart } from "./expense-chart"
import { MonthlyChart } from "./monthly-chart"
import { TransactionList } from "./transaction-list"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import { apiClient } from "@/lib/api-client"

interface Transaction {
  id: string
  type: "income" | "expense"
  category: string
  amount: number
  date: string
  description: string
}

interface DashboardProps {
  user: { id: string; name: string; email: string } | null
  onLogout: () => void
}

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [showForm, setShowForm] = useState(false)
  const [formType, setFormType] = useState<"income" | "expense">("expense")

  useEffect(() => {
    const loadTransactions = async () => {
      try {
        setLoading(true)
        const data = await apiClient.getTransactions()
        setTransactions(data)
        setError(null)
      } catch (err) {
        setError("Failed to load transactions")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    loadTransactions()
  }, [])

  const stats = useMemo(() => {
    const income = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
    const expenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
    const balance = income - expenses

    const incomeByCategory = transactions
      .filter((t) => t.type === "income")
      .reduce(
        (acc, t) => {
          acc[t.category] = (acc[t.category] || 0) + t.amount
          return acc
        },
        {} as Record<string, number>,
      )

    const expenseByCategory = transactions
      .filter((t) => t.type === "expense")
      .reduce(
        (acc, t) => {
          acc[t.category] = (acc[t.category] || 0) + t.amount
          return acc
        },
        {} as Record<string, number>,
      )

    const monthlyData: Record<string, { income: number; expense: number }> = {}
    transactions.forEach((t) => {
      const month = t.date.substring(0, 7)
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expense: 0 }
      }
      if (t.type === "income") {
        monthlyData[month].income += t.amount
      } else {
        monthlyData[month].expense += t.amount
      }
    })

    return {
      income,
      expenses,
      balance,
      incomeByCategory,
      expenseByCategory,
      monthlyData,
    }
  }, [transactions])

  const handleAddTransaction = async (transaction: Omit<Transaction, "id">) => {
    try {
      const newTransaction = await apiClient.createTransaction(transaction)
      setTransactions((prev) => [newTransaction, ...prev])
      setShowForm(false)
    } catch (err) {
      setError("Failed to add transaction")
      console.error(err)
    }
  }

  const handleDeleteTransaction = async (id: string) => {
    try {
      await apiClient.deleteTransaction(id)
      setTransactions((prev) => prev.filter((t) => t.id !== id))
    } catch (err) {
      setError("Failed to delete transaction")
      console.error(err)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">$</span>
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">ExpenseTracker</h1>
              <p className="text-slate-400 text-xs">Welcome, {user?.name}</p>
            </div>
          </div>
          <Button
            onClick={onLogout}
            variant="outline"
            size="sm"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Error Message */}
        {error && (
          <div className="mb-4 p-4 bg-red-500/10 border border-red-500/50 text-red-400 rounded-lg">{error}</div>
        )}

        {/* Loading State */}
        {loading ? (
          <div className="text-center py-12">
            <p className="text-slate-400">Loading transactions...</p>
          </div>
        ) : (
          <>
            {/* Balance Display */}
            <BalanceDisplay balance={stats.balance} income={stats.income} expenses={stats.expenses} />

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
              {/* Left - Expense Chart */}
              <ExpenseChart data={stats.expenseByCategory} />

              {/* Center - Monthly Chart */}
              <MonthlyChart data={stats.monthlyData} />

              {/* Right - Income Chart */}
              <IncomeChart data={stats.incomeByCategory} />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 justify-center mt-8">
              <Button
                onClick={() => {
                  setFormType("income")
                  setShowForm(true)
                }}
                className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold px-8"
              >
                + Add Income
              </Button>
              <Button
                onClick={() => {
                  setFormType("expense")
                  setShowForm(true)
                }}
                className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold px-8"
              >
                + Add Expense
              </Button>
            </div>

            {/* Transaction Form Modal */}
            {showForm && (
              <TransactionForm type={formType} onSubmit={handleAddTransaction} onClose={() => setShowForm(false)} />
            )}

            {/* Recent Transactions */}
            <div className="mt-8">
              <TransactionList transactions={transactions} onDelete={handleDeleteTransaction} />
            </div>
          </>
        )}
      </div>
    </div>
  )
}
